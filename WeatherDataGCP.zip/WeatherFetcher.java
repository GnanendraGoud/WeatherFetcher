import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class WeatherFetcher {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter City Name: ");
        String city = sc.nextLine();
        sc.close();

        // Replace with your OpenWeatherMap API key
        String apiKey = "YOUR_API_KEY";
        String apiUrl = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + apiKey + "&units=metric";

        try {
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            if (conn.getResponseCode() != 200) {
                System.out.println("Error: Unable to fetch data. Response code: " + conn.getResponseCode());
                return;
            }

            BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Save to local file
            FileWriter file = new FileWriter("weather_report.txt");
            file.write(response.toString());
            file.close();

            System.out.println("✅ Weather data saved in weather_report.txt");

        } catch (Exception e) {
            System.out.println("Error occurred: " + e.getMessage());
        }
    }
}
