# ☁️ Weather Data Fetcher using Google Cloud Platform (GCP)

## 📘 Project Overview
A beginner-friendly Java project that fetches live weather data using OpenWeatherMap API and uploads it to **Google Cloud Storage (GCS)**.

### 🧩 Tech Stack
- Java (Core Java)
- REST API (OpenWeatherMap)
- Google Cloud Storage (GCS)
- gcloud CLI / gsutil

---

## ⚙️ Steps to Run

### 1️⃣ Compile and Run Java Program
```bash
javac WeatherFetcher.java
java WeatherFetcher
```
Enter a city name (e.g., Hyderabad).  
The output will be saved in a file named `weather_report.txt`.

---

### 2️⃣ Upload to Google Cloud Storage
1. Create a GCS bucket on GCP Console → Storage → Buckets → Create.  
2. Use gsutil to upload:
   ```bash
   gsutil cp weather_report.txt gs://your-bucket-name/
   ```

---

## 🧠 Learning Outcomes
- Using Java to call APIs
- Integrating Java with Cloud Storage
- Understanding cloud data management

---

## 🇮🇳 Telugu + English Summary
**English:** This project fetches weather data using Java and stores it on Google Cloud.  
**తెలుగు:** ఈ ప్రాజెక్ట్ Java ద్వారా వాతావరణ సమాచారం తీసుకుని Google Cloud Storage లో ఉంచుతుంది.

**One-liner:** “Java app fetching weather data and storing it on GCP Cloud Storage.”
